<?php  
//include('dbconnect.php');
$conn=mysqli_connect('localhost','id20219598_project','NVCOIo&]-8k9Vudw','id20219598_smartcity');
?>