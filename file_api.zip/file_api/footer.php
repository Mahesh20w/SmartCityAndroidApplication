<footer class="main-footer">
  <div align="center">
    <strong></a>.</strong> 
    reserved.
    </div>
  </footer>
  
  
  
